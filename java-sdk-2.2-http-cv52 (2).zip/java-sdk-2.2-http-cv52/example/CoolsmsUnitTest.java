import static org.junit.Assert.*;
import java.util.HashMap;
import net.nurigo.java_sdk.api.Message;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.junit.Test;

public class CoolsmsUnitTest {

  @Test
  public void MessageTest(String UserPhoneNumber) throws Exception {

    String api_key = "NCSJPHS6YFMWD0MO";
    String api_secret = "PHB3O1AOPMZ0LPY2DBQEDEVAAEOVZRNI";

    String key = new TempKey().getKey(6);
    System.out.println(key);     //키 전송 부분

    Message message = new Message(api_key, api_secret);

    JSONObject result;
    HashMap<String, String> params = new HashMap<String, String>();

    try {
      // send
      params.put("to", UserPhoneNumber);
      params.put("from", "01032042646");
      params.put("type", "SMS");
      params.put("text", "안녕하세요 홍길동입니다. 인증번호는 [" + key + "] 입니다.");
      params.put("mode", "test");

      result = message.send(params);
      assertNotNull(result.get("group_id"));

      // balance
      result = message.balance();
      assertNotNull(result.get("cash"));

      // sent
      params.clear();
      try {
        result = message.sent(params);
        assertNotNull(result.get("data"));
      } catch (Exception e) {
        result = (JSONObject) JSONValue.parse(e.getMessage());
        assertEquals(result.get("code"), "NoSuchMessage");
      }

      // status
      result = message.getStatus(params);
      assertNotNull(result.get("data"));

      // cancel
      params.put("mid", "MIDTEST");
      result = message.cancel(params);
      assertTrue(!result.isEmpty());
    } catch (Exception e) {

//      fail(e.toString());
    }
  }
}
