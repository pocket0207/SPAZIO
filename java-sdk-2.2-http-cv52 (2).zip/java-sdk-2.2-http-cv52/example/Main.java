public class Main {
    public static void main(String[] args) {
        CoolsmsUnitTest cl = new CoolsmsUnitTest();
        try {
            cl.MessageTest("01032042646");
            // 입력 받는 부분

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
